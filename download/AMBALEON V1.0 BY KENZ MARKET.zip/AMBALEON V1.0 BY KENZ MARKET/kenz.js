/**
 * 
 * 
 * SETTING OWNER DAN BOT KENZDEV
 * 
 * 
 */
 
global.thumb = "https://pomf2.lain.la/f/9g68i14o.png";
global.Nameowner = "Kenz Market"
global.NomorOwner = "6288215523477"
global.nameBot = "AMBALEON V1.0"
global.package = "KENZ MARKET"
global.packname = "Ambaleon V1.0"
global.author = "Kenz Market"
global.namepayment = "KENZ MARKET REAL"
global.qrisId = 2
global.password = "kenz"

global.mess = {
  wait: "\`⏳ Tunggu yo bang\`",
  err: "Maaf Bang Sedang Error",
  load: "\`LOADING BRO SABAR\`",
  owner: "Maaf Anda Bukan Owner🗿"
}
