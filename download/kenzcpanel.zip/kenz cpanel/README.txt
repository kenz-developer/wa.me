===========================================
   • Script    : Cpanel Button Simple
   • Developer : FlowFalcon 
   • Version   : 1.0
   • Type      : Free
===========================================
Script ini gratis dan bisa di dapatkan 
di group / channel WhatsApp kami

Login Dengan Akun Yang Terdaftar 
Dengan Nomor Bot Anda

Jika Tidak Ada Akun Silahkan Registrasi
Di Group WhatsApp Kami Terlebih Dahulu

  • Group Chat : https://flowfalcon.xyz/group/

  • Channel    : https://flowfalcon.xyz/channel/

===========================================

THANKS TO
   *• Afgan : Pemilik Base Ori*
   *• AlwaysRicky : Teman Yang Memberikan Script* 
   *• Fathur : Teman Yang Membantu Membuat Fitur*
   *• AI : Untuk Menanyakan Fitur Error*
   *• Diri Saya Sendiri*