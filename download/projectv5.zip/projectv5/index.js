// Import module yang diperlukan
const TelegramBot = require('node-telegram-bot-api');
const caseConverter = require('case');
require('dotenv').config();

// Ganti dengan token bot Anda
const token = '7772739131:AAG0soiBKNXs5L2cuE0VG3n8H_fYCBXiWmU';
const axios = require('axios');
const fs = require("fs")
const colors = require("colors")
const moment = require("moment-timezone")
const osUtils = require("os-utils")
const os = require("os")
const JavaScriptObfuscator = require("javascript-obfuscator")
const fetch = require("node-fetch")

const BITLY_TOKEN = "b3424ee155a5adefe6b0a69159162d378126a26d"; // Ganti dengan token API Bitly Anda
const YOUTUBE_API_KEY = "AIzaSyBziqC1Q3W5b_-j_Z8d3kqZY-_SJ_SvOv8"
// Masukkan API Key NewsAPI Anda
const NEWS_API_KEY = "2009dbd6507e400dbedc5ae4a3ec451a"; // Ganti dengan API key dari NewsAPI
const ytdl = require("ytdl-core")
const ytsr = require("ytsr")
const path = require("path")
const https = require("https")
const InstagramScraper = require("instagram-scraper")
const cheerio = require("cheerio")
const QRCode = require("qrcode");
const xml2js = require('xml2js');

// Masukkan API Key OpenAI GPT-3 Anda
const OPENAI_API_KEY = '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'; // Ganti dengan API Key GPT-3 Anda

// URL API OpenAI GPT-3
const OPENAI_API_URL = 'https://api.openai.com/v1/completions';

// Fungsi untuk mendapatkan respons dari GPT-3
async function getAIResponse(text) {
  try {
    const response = await fetch(OPENAI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'text-davinci-003',
        prompt: text,
        max_tokens: 150,
        temperature: 0.7,
      }),
    });

    const data = await response.json();
    return data.choices[0].text.trim() || 'Maaf, saya tidak mengerti.';
  } catch (error) {
    console.error('Error fetching from GPT-3 API:', error);
    return 'Terjadi kesalahan saat mengambil respons.';
  }
}

const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
const wib = moment(Date.now())
    .tz("Asia/Jakarta")
    .locale("id")
    .format("HH:mm:ss z");
// Membuat bot menggunakan polling
const bot = new TelegramBot(token, { polling: true });

let userState = {}
let investasiPengguna = {}
// Data lelang saham
let lelang = {
  aktif: false,
  saham: null,
  hargaAwal: 0,
  penawaran: [], // Array untuk menyimpan penawaran (userId, nama, dan jumlah penawaran)
};

// Fungsi untuk mencari lirik lagu
async function cariLirik(lagu) {
  const url = `https://api.lyrics.ovh/v1/${lagu}`;
  const response = await fetch(url);
  const data = await response.json();
  if (data.lyrics) {
    return data.lyrics;
  } else {
    return 'Lirik lagu tidak ditemukan.';
  }
}

// Admin Telegram ID (admin yang akan menerima konfirmasi pembayaran)
const ADMIN_ID = '7299507029'; // Ganti dengan ID Telegram admin Anda

// Data jasa
const jasaData = {
    installPanel: {
        nama: '🖥️ Jasa Install Panel',
        harga: 'Rp5.000',
        deskripsi: '🚀 Install panel website sesuai kebutuhan Anda.',
    },
    unbandNomor: {
        nama: '🔓 Jasa Unband Nomor',
        harga: 'Rp15.000',
        deskripsi: '💳 Jasa unband nomor yang diblokir.',
    },
    bandNomor: {
        nama: '🔒 Jasa Band Nomor',
        harga: 'Rp20.000',
        deskripsi: '⚡ Jasa band nomor sesuai permintaan.',
    },
    jasteb: {
        nama: '💼 Jasa Jasteb',
        harga: 'Rp25.000',
        deskripsi: '🔧 Jasa jasteb untuk meningkatkan kualitas kerja.',
    }
};

// Data produk yang tersedia di toko
const products = [
  { id: 1, name: 'VPS', price: 'Rp 50,000', description: 'VPS dengan spesifikasi tinggi.' },
  { id: 2, name: 'Script', price: 'Rp 30,000', description: 'Script untuk automasi dan bot.' },
  { id: 3, name: 'Nokos', price: 'Rp 20,000', description: 'Paket nokos dengan layanan terbaik.' },
  { id: 4, name: 'Domain', price: 'Rp 25,000', description: 'Pendaftaran domain dengan nama pilihan.' },
  { id: 5, name: 'Subdomain', price: 'Rp 10,000', description: 'Pendaftaran subdomain untuk website.' },
  { id: 6, name: 'Panel', price: 'Rp 1,000', description: 'Panel untuk mengelola VPS atau server.' },
  { id: 7, name: 'Jasteb', price: 'Rp 25,000', description: 'Jasa teknologi dan pengembangan aplikasi.' }
];

// Fungsi untuk menampilkan daftar produk di toko
function showShopMenu(chatId) {
  let message = '📜 Toko Layanan Kami 📜\n\nPilih layanan yang Anda inginkan:\n\n';

  products.forEach((product, index) => {
    message += `${index + 1}. ${product.name} - ${product.price} - ${product.description}\n`;
  });

  message += '\nKetik nomor layanan yang ingin Anda beli.';
  bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

// Fungsi untuk memproses pemesanan produk
function processOrder(chatId, productId) {
  const product = products[productId - 1];
  if (product) {
    bot.sendMessage(chatId, `💰 Anda telah memilih: ${product.name}\n\nHarga: ${product.price}\nDeskripsi: ${product.description}\n\nSilakan lakukan pembayaran dan konfirmasi ke admin.\n\nJika sudah melakukan pembayaran, ketik /konfirmasi untuk melanjutkan.`);
  } else {
    bot.sendMessage(chatId, '❌ Produk tidak ditemukan!');
  }
}

// Fungsi untuk konfirmasi pembayaran
function confirmPayment(chatId) {
  bot.sendMessage(chatId, '✅ Pembayaran telah terkonfirmasi. Anda akan menerima produk atau layanan dalam waktu dekat. Terima kasih atas transaksi Anda! 🙏');
}

// Variabel untuk menyimpan data transfer sementara
let transferData = {};

// Fungsi untuk menyimpan data transfer sementara
function addTransferData(chatId, jumlahTransfer) {
    transferData[chatId] = {
        jumlahTransfer,
        status: 'Pending',
        timestamp: Date.now(), // Menyimpan waktu transfer
    };
}

// Fungsi untuk menghasilkan hasil acak cek kecantikan
function getBeautyRating() {
  const ratings = [
    "🌟 Kamu sangat cantik, seperti bintang di langit! 🌟",
    "✨ Kamu mempesona, kecantikanmu luar biasa! ✨",
    "💖 Kamu seperti bunga yang sedang mekar, cantik sekali! 💖",
    "😍 Kamu cantik luar biasa, semua mata tertuju padamu! 😍",
    "💫 Wajahmu seperti cahaya yang menerangi ruangan! 💫",
    "🔥 Kamu sangat mempesona, kecantikanmu tak terbantahkan! 🔥",
    "🌸 Kamu sangat cantik, semua orang akan terpesona padamu! 🌸",
    "🌺 Kecantikanmu seperti bunga yang indah dan harum! 🌺",
    "🌼 Kamu seperti sinar matahari yang membuat dunia lebih cerah! 🌼",
    "🌷 Setiap kali kamu tersenyum, dunia menjadi lebih indah! 🌷",
    "💫 Kecantikanmu tidak ada duanya, seperti permata langka! 💫",
    "💎 Kamu adalah permata yang sangat berharga! 💎",
    "🌹 Seperti mawar yang mekar, kamu memancarkan keindahan alami! 🌹",
    "🌻 Kamu cantik dalam segala hal, dalam kata dan tindakan! 🌻",
    "🍀 Seperti daun hijau yang segar, kamu selalu membawa keceriaan! 🍀",
    "💖 Kamu memiliki pesona yang tak terbantahkan, memikat hati setiap orang! 💖",
    "✨ Tiap detik kamu semakin cantik dan menawan! ✨",
    "🌸 Keindahanmu membuat semua orang terpesona! 🌸",
    "💫 Kecantikanmu lebih bercahaya daripada bintang-bintang di malam hari! 💫",
    "🌙 Kecantikanmu adalah hadiah dari langit! 🌙",
    "🌞 Kamu adalah matahari yang bersinar di hari yang cerah! 🌞",
    "🌷 Kamu memiliki kecantikan yang menyinari jalan setiap orang! 🌷",
    "🌻 Tiap senyummu adalah kebahagiaan yang tak ternilai! 🌻",
    "💖 Kamu adalah dambaan hati banyak orang, sangat menawan! 💖",
    "✨ Kamu memiliki kecantikan yang mempesona dan memesona! ✨",
    "🌹 Kecantikanmu tak hanya di luar, tapi juga di dalam! 🌹",
    "💎 Setiap gerakanmu penuh dengan keanggunan yang menakjubkan! 💎",
    "🍁 Kecantikanmu seperti musim semi yang penuh warna dan keceriaan! 🍁",
    "🍃 Kamu sangat anggun, seperti angin yang lembut dan menenangkan! 🍃",
    "🌸 Dunia ini menjadi lebih indah karena ada kamu! 🌸",
    "🌼 Kamu adalah simbol kecantikan yang tak terlupakan! 🌼",
    "💐 Kamu adalah bunga yang paling menawan di taman dunia! 💐"
  ];

  // Mengembalikan nilai acak dari array ratings
  const randomIndex = Math.floor(Math.random() * ratings.length);
  return ratings[randomIndex];
}

// Fungsi untuk mendapatkan waktu respon server (ping)
function getServerPing() {
  return new Promise((resolve) => {
    const startTime = Date.now();
    // Mengukur waktu respons dengan mengirim pesan sederhana dan menghitung delay
    bot.sendMessage(chatId, 'Ping Test')
      .then(() => {
        const latency = Date.now() - startTime;
        resolve(latency);
      })
      .catch((error) => {
        resolve('Error pinging server');
      });
  });
}

// Fungsi untuk mendapatkan statistik CPU dan Memori
function getServerStats() {
  return new Promise((resolve, reject) => {
    const freeMemory = os.freemem();
    const totalMemory = os.totalmem();
    const memoryUsage = ((totalMemory - freeMemory) / totalMemory) * 100;

    // Menyusun pesan
    const serverStats = `
      🖥 Server Stats 🖥️
      💾 Memory Usage : ${Math.round(memoryUsage)}% of ${(totalMemory / 1024 / 1024).toFixed(2)} MB
    `;
    
    resolve(serverStats);
  });
}

// Fungsi untuk mengambil data gempa dari RSS Feed BMKG
function getEarthquakeFromRSS(callback) {
  const url = 'https://www.bmkg.go.id/gempabumi/gempabumi-terkini.rss'; // URL RSS Feed BMKG

  // Melakukan request HTTPS untuk mengambil data RSS
  https.get(url, (res) => {
    let data = '';

    // Menerima data RSS
    res.on('data', (chunk) => {
      data += chunk;
    });

    // Setelah selesai menerima data
    res.on('end', () => {
      // Menggunakan xml2js untuk mengonversi XML ke format JSON
      xml2js.parseString(data, (err, result) => {
        if (err) {
          callback('Terjadi kesalahan dalam mengambil data.');
          return;
        }

        // Mengambil informasi gempa dari hasil parsing XML
        const items = result.rss.channel[0].item;
        if (items && items.length > 0) {
          const earthquake = items[0];
          const title = earthquake.title[0];
          const link = earthquake.link[0];
          const pubDate = earthquake.pubDate[0];

          const earthquakeInfo = `🌍 *Gempa Terbaru*\n- Judul: ${title}\n- Waktu: ${pubDate}\n- Link: ${link}\n`;

          callback(earthquakeInfo);
        } else {
          callback('Tidak ada informasi gempa terbaru.');
        }
      });
    });
  }).on('error', (e) => {
    callback('Terjadi kesalahan dalam mengambil data.');
  });
}

// Fungsi untuk mendapatkan khodam acak
function getKhodam() {
  const khodams = [
    { name: "Khodam Harimau", description: "💪 Khodam yang memiliki kekuatan dan keberanian seperti harimau.", emoji: "🐯" },
    { name: "Khodam Naga", description: "🐉 Khodam yang memiliki kekuatan magis dan kebijaksanaan yang tinggi.", emoji: "🔥" },
    { name: "Khodam Kucing", description: "😸 Khodam dengan kecerdasan dan keanggunan seperti seekor kucing.", emoji: "🐱" },
    { name: "Khodam Elang", description: "🦅 Khodam yang memiliki pandangan tajam dan kebebasan yang tinggi.", emoji: "💨" },
    { name: "Khodam Macan Putih", description: "👑 Khodam yang memiliki kekuatan luar biasa, sangat dihormati dan langka.", emoji: "🐅" },
    { name: "Khodam Burung Hantu", description: "🦉 Khodam yang bijaksana, memiliki penglihatan yang tajam di malam hari.", emoji: "🌙" },
    { name: "Khodam Kuda", description: "🐎 Khodam yang memiliki kecepatan dan kekuatan, selalu siap membantu.", emoji: "⚡" },
    { name: "Khodam Serigala", description: "🐺 Khodam yang memiliki kekuatan kelompok dan loyalitas tinggi.", emoji: "🌲" },
    { name: "Khodam Jin", description: "🧞‍♂️ Khodam yang memiliki kekuatan magis, bisa memberikan keinginan dan sihir.", emoji: "✨" },
    { name: "Khodam Dewa", description: "🕊️ Khodam yang memiliki kekuatan ilahi dan kekuatan tak terbatas.", emoji: "👑" }
  ];

  // Mengambil khodam acak
  const randomIndex = Math.floor(Math.random() * khodams.length);
  return khodams[randomIndex];
}

// Fungsi untuk mengacak tingkat kegantengan
function getGantengLevel() {
  const levels = [
    { level: "✨ Super Ganteng ✨", emoji: "😎" },
    { level: "😏 Ganteng Banget!", emoji: "😎" },
    { level: "😊 Ganteng", emoji: "😊" },
    { level: "😅 Cukup Ganteng", emoji: "😅" },
    { level: "😆 Biasa Aja", emoji: "🤔" },
    { level: "😂 Gak Ganteng Sama Sekali", emoji: "😜" }
  ];

  // Mengambil level acak
  const randomIndex = Math.floor(Math.random() * levels.length);
  return levels[randomIndex];
}

// Fungsi untuk mendapatkan berita terbaru menggunakan NewsAPI
async function getLatestNews() {
  const url = `https://newsapi.org/v2/top-headlines?country=id&apiKey=${NEWS_API_KEY}`;

  try {
    const response = await axios.get(url);
    const articles = response.data.articles;

    if (articles.length === 0) {
      return "Tidak ada berita terbaru saat ini.";
    }

    let newsMessage = "📰 **Berita Terbaru:**\n\n";

    // Ambil beberapa artikel terbaru dan formatkan pesan
    articles.slice(0, 5).forEach((article, index) => {
      newsMessage += `🔹 *${article.title}*\n`;
      newsMessage += `${article.description}\n`;
      newsMessage += `[Baca Selengkapnya](${article.url})\n\n`;
    });

    return newsMessage;
  } catch (error) {
    console.error("Error fetching news:", error);
    return "Terjadi kesalahan saat mengambil berita.";
  }
}

// Base URL API QRIS
const QRIS_API_URL = "https://qris-ku.autsc.my.id/api/create?";

// Fungsi untuk membuat QRIS URL
function generateQRISURL(amount) {
  const encodedAmount = encodeURIComponent(amount); // Encode nominal untuk URL
  const qrisCode =
    "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214515291627902280303UMI51440014ID.CO.QRIS.WWW0215ID20253689355520303UMI5204541153033605802ID5921KENZ%MARKET OK21700366006CIAMIS61054621162070703A01630476B1";

  return `${QRIS_API_URL}amount=${encodedAmount}&qrisCode=${qrisCode}`;
}

// File untuk menyimpan ID Telegram yang sudah diisi
const idFilePath = 'id.json';

// Fungsi untuk mengambil ID pengguna yang sudah terdaftar
function getRegisteredIds() {
  if (fs.existsSync(idFilePath)) {
    return JSON.parse(fs.readFileSync(idFilePath, 'utf8'));
  } else {
    return [];
  }
}

// Fungsi untuk menambahkan ID Telegram ke dalam file
function addUserId(userId) {
  const registeredIds = getRegisteredIds();
  if (!registeredIds.includes(userId)) {
    registeredIds.push(userId);
    fs.writeFileSync(idFilePath, JSON.stringify(registeredIds), 'utf8');
  }
}

// Fungsi untuk memeriksa apakah ID Telegram sudah terdaftar
function isUserRegistered(userId) {
  const registeredIds = getRegisteredIds();
  return registeredIds.includes(userId);
}

// Fungsi untuk mengupdate harga saham
function generateSaham() {
  // Nilai saham acak antara 1000 hingga 5000
  const hargaSaham = Math.floor(Math.random() * (50000 - 1000 + 1)) + 1000;
  
  // Acak pergerakan naik/turun
  const naikTurun = Math.random() < 0.5 ? "naik" : "turun";
  const emoji = naikTurun === "naik" ? "📈" : "📉"; // Emoji untuk naik dan turun
  
  return { hargaSaham, naikTurun, emoji };
}


// Fungsi untuk format rupiah
const formatRupiah = (number) => {
  return `Rp${number.toLocaleString()}`;
};

// Fungsi untuk menghitung total investasi
function hitungKeuntungan(investasiAwal, persenKeuntungan) {
  return investasiAwal + (investasiAwal * persenKeuntungan) / 100;
}

// Fungsi untuk membuat struktur pembayaran otomatis
function buatStrukturPembayaran(namaBarang, hargaBarang, jumlahBeli) {
  const tanggal = new Date().toLocaleDateString(); // Mengambil tanggal saat ini (format: MM/DD/YYYY)
  const totalHarga = hargaBarang * jumlahBeli;

  return `
🎉 **STRUKTUR PEMBAYARAN** 🎉

🛒 Nama Barang : ${namaBarang}
💵 Harga Satuan : ${hargaBarang} IDR
🔢 Jumlah Beli : ${jumlahBeli}
📅 Tanggal Pembelian : ${tanggal}
💰 Total Harga : ${totalHarga} IDR

📝 Catatan :
Harap simpan struk ini sebagai bukti transaksi.
All TRX No Reff

🔥 Terima Kasih telah membeli di KenzDev 2025! 🔥

🔄 Salin struk ini untuk transaksi Anda.
  `; // Struktur pembayaran
}

// Fungsi untuk membuat teks payment dengan hiasan
function generatePaymentText(namaDana, nomorDana, namaGoPay, nomorGoPay, qrisURL) {
  return `
🎉 INFORMASI PEMBAYARAN 🎉

💳 Metode Pembayaran yang Tersedia :
  
🔷 DANA
   - 📛 Atas Nama : ${namaDana}
   - 📞 Nomor : ${nomorDana}
   
🔷 GO-PAY
   - 📛 Atas Nama : ${namaGoPay}
   - 📞 Nomor : ${nomorGoPay}
   
🔷 QRIS
   - 🔗 Link QRIS: [Qris All Payment](${qrisURL})

📝 Harap pastikan semua informasi benar sebelum melakukan pembayaran. 
✨ Terima Kasih telah menggunakan layanan kami! ✨
  `;
}

// Fungsi membaca dan menulis file JSON
function readJSON(file) {
  return JSON.parse(fs.readFileSync(file));
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function generateTRXCode(length = 10) {
            const characters =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            let TRXCode = "";

            for (let i = 0; i < length; i++) {
                TRXCode += characters.charAt(
                    Math.floor(Math.random() * characters.length)
                );
            }

            return TRXCode;
        }
        const TRXCode = generateNOCode(30);
function generateNOCode(length = 10) {
            const characters =
                "0123456789";
            let NOCode = "";

            for (let i = 0; i < length; i++) {
                NOCode += characters.charAt(
                    Math.floor(Math.random() * characters.length)
                );
            }

            return NOCode;
        }
        const NOCode = generateNOCode(10);
let transactionCount = 0;

// Data Jadwal Puasa
// Tanggal awal Ramadan (disesuaikan setiap tahun)
const tanggalPuasa = new Date('2025-03-10T00:00:00'); // Contoh: 1 Ramadan 1446 H (10 Maret 2025)

// Fungsi untuk menghitung waktu mundur
function hitungWaktuMundur() {
  const sekarang = new Date();
  const selisihWaktu = tanggalPuasa - sekarang;

  if (selisihWaktu <= 0) {
    return "🌙 Ramadan telah dimulai! Selamat menunaikan ibadah puasa!";
  }

  const hari = Math.floor(selisihWaktu / (1000 * 60 * 60 * 24));
  const jam = Math.floor((selisihWaktu % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const menit = Math.floor((selisihWaktu % (1000 * 60 * 60)) / (1000 * 60));
  const detik = Math.floor((selisihWaktu % (1000 * 60)) / 1000);

  return `⏳ Waktu menuju Ramadan:
\n${hari} hari
${jam} jam
${menit} menit
${detik} detik`;
}

// Simpan waktu saat bot pertama kali dijalankan
const startTime = Date.now();

// Fungsi untuk menghitung waktu aktif bot
function getUptime() {
  const now = Date.now();
  const uptimeMillis = now - startTime;

  // Menghitung hari, jam, menit, detik
  const days = Math.floor(uptimeMillis / (1000 * 60 * 60 * 24));
  const hours = Math.floor((uptimeMillis % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((uptimeMillis % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((uptimeMillis % (1000 * 60)) / 1000);

  // Format waktu aktif bot
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${seconds} Detik`;
}

// Fungsi untuk simulasi loading dengan teks animasi
async function loadingAnimation(chatId) {
  const loadingTexts = [
    "Loading.",
    "Loading..",
    "Loading...",
    "Loading....",
    "Loading....."
  ];

  // Loop untuk menampilkan animasi loading
  for (let i = 0; i < loadingTexts.length; i++) {
    await new Promise((resolve) => {
      setTimeout(() => {
        bot.sendMessage(chatId, loadingTexts[i]);
        resolve();
      }, 1000); // Mengatur jeda 1 detik untuk setiap perubahan teks
    });
  }

  // Setelah loading selesai, kirim pesan selesai
  bot.sendMessage(chatId, "✅ LOADING SUDAH SELESAI SILAHKAN KLIK INI /menu");
}

// Cloudflare API Credentials
const CLOUDFLARE_API_TOKEN = "CSQecWRYUv-CVDsVAWESF2PEs3B7LLzg9fCbvaio"; // Ganti dengan token API Cloudflare
const CLOUDFLARE_ZONE_ID = "af3a43cf8de9daca9fc91e50453e4c36"; // Ganti dengan Zone ID Cloudflare
const DOMAIN_NAME = "host-server-pterodactyl.my.id"; // Ganti dengan domain utama Anda

// Fungsi untuk membuat subdomain
async function buatSubdomain(subdomain, ip) {
  try {
    const response = await axios.post(
      `https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns/records`,
      {
        type: "A", // Jenis record (A untuk IP v4)
        name: `${subdomain}.${DOMAIN_NAME}`, // Nama subdomain
        content: ip, // Alamat IP untuk subdomain
        ttl: auto, // TTL (Time to Live)
        proxied: false, // Tidak menggunakan proxy Cloudflare
      },
      {
        headers: {
          Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (response.data.success) {
      return `✅ Subdomain berhasil dibuat: https://${subdomain}.${DOMAIN_NAME}`;
    } else {
      return `❌ Gagal membuat subdomain: ${response.data.errors[0].message}`;
    }
  } catch (error) {
    console.error(error);
    return "❌ Terjadi kesalahan saat membuat subdomain.";
  }
}

// Fungsi untuk menambahkan pengguna ke file JSON
function addUserToFile(userId, filePath, role) {
  const data = readJSON(filePath);
  if (!data.some((user) => user.id === userId)) {
    data.push({ id: userId, role });
    writeJSON(filePath, data);
  }
}

// Fungsi untuk mengecek status pengguna
function getUserRole(userId) {
  if (readJSON("prem.json").some((user) => user.id == userId)) return "premium";
  if (readJSON("VIP.json").some((user) => user.id == userId)) return "vip";
  if (readJSON("seller.json").some((user) => user.id == userId)) return "reseller";
  return "regular";
}

// Fungsi untuk membuat shortlink menggunakan Bitly API
async function createShortlink(longUrl) {
  try {
    const response = await axios.post(
      "https://api-ssl.bitly.com/v4/shorten",
      {
        long_url: longUrl,
        domain: "bit.ly",
      },
      {
        headers: {
          Authorization: `Bearer ${BITLY_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.link; // Mengembalikan link pendek
  } catch (error) {
    console.error("Error saat membuat shortlink:", error.response.data);
    throw new Error("Gagal membuat shortlink. Pastikan URL yang Anda masukkan valid.");
  }
}

async function createShortlink1(longUrl1) {
  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(longUrl1)}`);
    return response.data; // Mengembalikan link pendek
  } catch (error) {
    console.error("Error saat membuat shortlink:", error);
    throw new Error("Gagal membuat shortlink. Pastikan URL yang Anda masukkan valid.");
  }
}

// Fungsi untuk menghitung tanggal Hijriah
function gregorianToHijri(gregorianDate) {
  // Konstanta perhitungan
  const GREGORIAN_EPOCH = 1721425.5;
  const HIJRI_EPOCH = 1948439.5;

  // Fungsi untuk menghitung Julian Day Number (JDN)
  function julianDay(year, month, day) {
    return (
      GREGORIAN_EPOCH -
      1 +
      365 * (year - 1) +
      Math.floor((year - 1) / 4) -
      Math.floor((year - 1) / 100) +
      Math.floor((year - 1) / 400) +
      Math.floor((367 * month - 362) / 12 + (month <= 2 ? 0 : (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? -1 : -2) + day)
    );
  }

  // Ambil tahun, bulan, dan tanggal dari tanggal Gregorian
  const year = gregorianDate.getFullYear();
  const month = gregorianDate.getMonth() + 1; // Bulan dimulai dari 0, tambahkan 1
  const day = gregorianDate.getDate();

  // Hitung JDN untuk tanggal Gregorian
  const jd = julianDay(year, month, day);

  // Hitung tanggal Hijriah
  const hijriDays = Math.floor(jd - HIJRI_EPOCH);
  const hijriYear = Math.floor((30 * hijriDays + 10646) / 10631);
  const hijriMonth = Math.min(
    12,
    Math.ceil((hijriDays - (29 + hijriYear * 354 + Math.floor((3 + 11 * hijriYear) / 30))) / 29.5) + 1
  );
  const hijriDay = hijriDays - Math.floor(29.5 * (hijriMonth - 1)) - (hijriYear * 354 + Math.floor((3 + 11 * hijriYear) / 30));

  return {
    year: hijriYear,
    month: hijriMonth,
    day: hijriDay,
  };
}

// Contoh Penggunaan
const today = new Date(); // Tanggal hari ini
const hijriDate = gregorianToHijri(today);

console.log(`Tanggal Hijriah: ${hijriDate.day}-${hijriDate.month}-${hijriDate.year}`);

// Fungsi untuk menghitung waktu menuju tahun baru
// Fungsi untuk menghitung waktu menuju Tahun Baru
function calculateTimeLeft() {
  const now = new Date();
  const nextYear = now.getFullYear() + 1;
  const newYearDate = new Date(`${nextYear}-01-01T00:00:00`);
  const timeLeft = newYearDate - now;

  const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
  const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

  return { days, hours, minutes, seconds, timeLeft };
}

// Fungsi format pesan
function formatTimeLeft(time) {
  return `⏳ Menuju Tahun Baru:\n` +
         `${time.days} hari, ${time.hours} jam, ${time.minutes} menit, ${time.seconds} detik lagi!`;
}

// Fungsi untuk menunggu Tahun Baru
function waitForNewYear(chatId) {
  const interval = setInterval(() => {
    const time = calculateTimeLeft();

    // Jika sudah mencapai Tahun Baru
    if (time.timeLeft <= 0) {
      bot.sendMessage(chatId, "🎉 Selamat Tahun Baru! 🎊");
      clearInterval(interval);
    }
  }, 1000);
}

// Fungsi untuk mencari video di YouTube
async function searchYouTube(query) {
  const searchResults = await ytsr(query, { limit: 1 });
  return searchResults.items[0]?.url || null;
}

// Fungsi untuk mengunduh audio dari YouTube
async function downloadAudio(videoUrl, outputPath) {
  return new Promise((resolve, reject) => {
    const stream = ytdl(videoUrl, { filter: "audioonly" })
      .pipe(fs.createWriteStream(outputPath));
    stream.on("finish", () => resolve(outputPath));
    stream.on("error", (err) => reject(err));
  });
}

// Fungsi untuk mendapatkan informasi video YouTube
function getYouTubeVideoInfo(videoId) {
  const apiUrl = `https://www.googleapis.com/youtube/v3/videos?id=${videoId}&key=${YOUTUBE_API_KEY}&part=snippet,contentDetails`;

  return new Promise((resolve, reject) => {
    https.get(apiUrl, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => resolve(JSON.parse(data)));
    }).on("error", (err) => reject(err));
  });
}

// Fungsi untuk mengunduh audio dari YouTube
function downloadYouTubeAudio(videoId, filePath) {
  const audioUrl = `https://www.yt-download.org/api/button/mp3/${videoId}`;
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filePath);
    https.get(audioUrl, (res) => {
      res.pipe(file);
      file.on("finish", () => {
        file.close();
        resolve(filePath);
      });
    }).on("error", (err) => {
      fs.unlink(filePath, () => reject(err));
    });
  });
}

// Fungsi untuk mengambil ID video dari URL
function extractVideoId(url) {
  const regex = /(?:youtube\.com\/.*v=|youtu\.be\/)([^&?]+)/;
  const match = url.match(regex);
  return match ? match[1] : null;
}

// Fungsi untuk mengirim gambar berdasarkan perintah
bot.onText(/\/qris/, (msg) => {
    const chatId = msg.chat.id;
    const sender1 = msg.from.username
    const user1 = msg.from.first_name
    transactionCount++;
    // Gambar yang akan dikirim (gunakan URL atau path file lokal)
    const imageUrl = './qris.jpg';  // Ganti dengan URL gambar Anda

    // Kirim gambar ke chat
    bot.sendPhoto(chatId, imageUrl,
    {
      caption: `Scan Qris Diatas Expired 5 Menit

A/N : KENZ MARKET

ID TRX : ${TRXCode}
NOMOR TRX : KNZ-${NOCode}
TRX KE : ${transactionCount}

USERNAME : ${sender1}
NAME : ${user1}

KIRIM BUKTI TF KE : @KenzDeveloper
`
    }
        ).then(() => {
            console.log('QRIS BERHASIL DIKIRIM'.green.bold);
        })
        .catch((error) => {
            console.error('Gagal mengirim gambar:'.red.bold, error);
        });
});
//=================//
bot.onText(/\/donasi/,async (msg) => {
  const img2url = "./qris.jpg"
  const chatId = msg.chat.id
  bot.sendPhoto(chatId, img2url, {
    caption: `QRIS A/N : KENZ MARKET

DANA : 085934686607
ATAS NAMA : xyzuujb

GOPAY : 085934686607
ATAS NAMA : TANYA KENZ
`
  })
  resultc = `KIRIM BUKTI TF KE OWNER SAYA🦆💨`
setTimeout(() => {;
bot.sendMessage(chatId, `\`\`\`\n${resultc}\n\`\`\``,
{ parse_mode: 'Markdown' })
},2000)
})
//==================//
bot.onText(/\/scfree1/, (msg) => {
  const chatId = msg.chat.id;

  // Path file yang ingin dikirim
  const filePath = './CPANELSIMPLEV4.zip'; // Ganti dengan path file Anda

  // Periksa apakah file ada
  if (fs.existsSync(filePath)) {
    bot.sendDocument(chatId, filePath)
      .then(() => {
        bot.sendMessage(chatId, 'Sc berhasil dikirim!');
        console.log("SCRIPT BERHASIL DIKIRIM".green.bold)
      })
      .catch((error) => {
        console.error('Error mengirim file:', error);
        bot.sendMessage(chatId, 'Gagal mengirim file.');
      });
  } else {
    bot.sendMessage(chatId, 'File tidak ditemukan.');
  }
});

bot.onText(/\/scfree2/, (msg) => {
  const chatId = msg.chat.id;

  // Path file yang ingin dikirim
  const filePath = './SCRIPTCPANEL.zip'; // Ganti dengan path file Anda

  // Periksa apakah file ada
  if (fs.existsSync(filePath)) {
    bot.sendDocument(chatId, filePath)
      .then(() => {
        bot.sendMessage(chatId, 'Sc berhasil dikirim!');
        console.log("SCRIPT BERHASIL DIKIRIM".green.bold)
      })
      .catch((error) => {
        console.error('Error mengirim file:', error);
        bot.sendMessage(chatId, 'Gagal mengirim file.');
      });
  } else {
    bot.sendMessage(chatId, 'File tidak ditemukan.');
  }
});

bot.onText(/\/scfree3/, (msg) => {
  const chatId = msg.chat.id;

  // Path file yang ingin dikirim
  const filePath = './SCRIPTV2FIX.zip'; // Ganti dengan path file Anda

  // Periksa apakah file ada
  if (fs.existsSync(filePath)) {
    bot.sendDocument(chatId, filePath,
    {
      caption: `SC FREE BY KENZDEV V2 FIX
      
JAM AMBIL SC : ${wib}`
    }
      ).then(() => {
        bot.sendMessage(chatId, 'Sc berhasil dikirim!');
        console.log("SCRIPT BERHASIL DIKIRIM".green.bold)
      })
      .catch((error) => {
        console.error('Error mengirim file:', error);
        bot.sendMessage(chatId, 'Gagal mengirim file.');
      });
  } else {
    bot.sendMessage(chatId, 'File tidak ditemukan.');
  }
});

//==================//
<!-- GACHA CUY -->
// Perintah /gachabiasa
bot.onText(/\/gachadragonbiasa/, (msg) => {
  const chatId = msg.chat.id;
  const reward = gachabiasa[Math.floor(Math.random() * gachabiasa.length)];
  bot.sendMessage(chatId, `🎉 Anda mendapatkan: ${reward}`);
});

/*
CODE BY KENZDEVELOPER 🐉
FITUR GACHA DRAGON PREMIUM
*/

const gachaItems = [
  "🐉 SCRIPT DEVELOPER",
  "🐉 ZONK BANG",
  "🐉 SCRIPT STORE V2",
];
const gachaItems2 = [
  "🐉 ZONK BANG",
  "🐉 SCRIPT PORTOFOLIO",
  "🐉 BIKIN BOT BASE",
];
const gachaItems3 = [
  "🐉 SCRIPT BOT TELE V4",
  "🐉 VPS RAM2CORE1 3 HARI",
  "🐉 SCRIPT WEB STORE V3",
];

bot.onText(/\/gachadragonpremium/, async (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "🟢 *Memulai Gacha Dragon Premium...* 🐉\n\n⏳ Tunggu sebentar ya!", {
    parse_mode: "Markdown",
  });

  // Animasi Loading
  const loadingFrames = ["🟥", "🟧", "🟨", "🟩", "🟦", "🟪"];
  let loadingIndex = 0;
  const loadingMessage = await bot.sendMessage(chatId, "🔄 Sedang memutar: " + loadingFrames[loadingIndex]);

  const loadingInterval = setInterval(async () => {
    loadingIndex = (loadingIndex + 1) % loadingFrames.length;
    bot.editMessageText("🔄 Sedang memutar: " + loadingFrames[loadingIndex], {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  }, 500);

  // Hasil Gacha setelah beberapa detik
  setTimeout(async () => {
    clearInterval(loadingInterval);

    const randomDragon = gachaItems[Math.floor(Math.random() * gachaItems.length)];
    bot.editMessageText("✅ *Gacha Selesai!*\n\nKamu mendapatkan:\n\n" + randomDragon, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
      parse_mode: "Markdown",
    });
  }, 5000); // Loading berlangsung selama 5 detik
});
bot.onText(/\/gachadragonbiasa/, async (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "🟢 *Memulai Gacha Dragon Premium...* 🐉\n\n⏳ Tunggu sebentar ya!", {
    parse_mode: "Markdown",
  });

  // Animasi Loading
  const loadingFrames = ["🟥", "🟧", "🟨", "🟩", "🟦", "🟪"];
  let loadingIndex = 0;
  const loadingMessage = await bot.sendMessage(chatId, "🔄 Sedang memutar: " + loadingFrames[loadingIndex]);

  const loadingInterval = setInterval(async () => {
    loadingIndex = (loadingIndex + 1) % loadingFrames.length;
    bot.editMessageText("🔄 Sedang memutar: " + loadingFrames[loadingIndex], {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  }, 500);

  // Hasil Gacha setelah beberapa detik
  setTimeout(async () => {
    clearInterval(loadingInterval);

    const randomDragon = gachaItems2[Math.floor(Math.random() * gachaItems.length)];
    bot.editMessageText("✅ *Gacha Selesai!*\n\nKamu mendapatkan:\n\n" + randomDragon, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
      parse_mode: "Markdown",
    });
  }, 5000); // Loading berlangsung selama 5 detik
});
bot.onText(/\/gachadragonvip/, async (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "🟢 *Memulai Gacha Dragon Premium...* 🐉\n\n⏳ Tunggu sebentar ya!", {
    parse_mode: "Markdown",
  });

  // Animasi Loading
  const loadingFrames = ["🟥", "🟧", "🟨", "🟩", "🟦", "🟪"];
  let loadingIndex = 0;
  const loadingMessage = await bot.sendMessage(chatId, "🔄 Sedang memutar: " + loadingFrames[loadingIndex]);

  const loadingInterval = setInterval(async () => {
    loadingIndex = (loadingIndex + 1) % loadingFrames.length;
    bot.editMessageText("🔄 Sedang memutar: " + loadingFrames[loadingIndex], {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  }, 500);

  // Hasil Gacha setelah beberapa detik
  setTimeout(async () => {
    clearInterval(loadingInterval);

    const randomDragon = gachaItems3[Math.floor(Math.random() * gachaItems.length)];
    bot.editMessageText("✅ *Gacha Selesai!*\n\nKamu mendapatkan:\n\n" + randomDragon, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
      parse_mode: "Markdown",
    });
  }, 5000); // Loading berlangsung selama 5 detik
});


//===============//
//menu
bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;
  const sender2 = msg.from.username
  const user2 = msg.from.first_name
  const uptime = getUptime();
  const imageUrl = './logo.jpg';  // Ganti dengan URL gambar Anda
  const time = calculateTimeLeft();


bot.sendMessage(chatId, `
⚙️ INFO BOT BY KENZDEV ⚙️

Detail tentang bot dan sistem yang digunakan:

🔷 NAME BOT: Project V5
🔷 OWNER: @KenzDeveloper
🔷 VERSION SC: V5
🔷 VERSION NODEJS: V23.6.0
🔷 VERSION NODEMON: 3.1.9
🔷 API INFO: @BotFather
🔷 BOT AKTIF: ${uptime}
🔷 PUKUL: ${wib} WIB
🔷 HIJRIAH DATE: ${hijriDate.day} ${hijriDate.month} - ${hijriDate.year}

👤 INFO USER 👤

Informasi terkait pengguna yang sedang aktif:

🔹 TAG: @${sender2}
🔹 USERNAME: ${sender2}
🔹 NAMA: ${user2}


✨ 🌐 MAIN MENU 🌐

Pilih salah satu opsi untuk memulai:

1. 💳 /qris
➡️ Dapatkan QR Code untuk pembayaran cepat dan mudah.

2. 🆓 /scfree1
➡️ Akses Script Free 1 secara gratis, segera digunakan!

3. 🆓 /scfree2
➡️ Nikmati Script Free 2 dengan fitur lengkap secara gratis.

4. 🆓 /scfree3
➡️ Script Free 3 gratis untuk digunakan langsung, coba sekarang!


🐉 🔥 GACHA DRAGON MENU 🔥

Leveled-up gacha dengan hadiah menggiurkan!

1. 🎁 /gachadragonpremium
➡️ Peluang gacha premium dengan hadiah luar biasa!


2. 🎲 /gachadragonbiasa
➡️ Gacha biasa dengan peluang menarik setiap kali kamu bermain.


3. 💥 /gachadragonsuper
➡️ Super gacha dengan peluang lebih besar dan hadiah langka!



⚙️ 🛠️ OTHER MENU 🛠️

Utilitas tambahan yang siap membantu kamu:

1. 💰 /buatpayment
➡️ Buat payment link untuk transaksi cepat dan aman.

2. 🔗 /shortlink
➡️ Buat URL pendek yang mudah dibagikan.

3. 🔗 /shortlink2
➡️ Link pendek dengan berbagai opsi kustomisasi.

4. 🎨 /buatcss
➡️ Buat kode CSS untuk desain web yang keren.

5. 🌐 /buathtml
➡️ Buat halaman HTML untuk website kamu dengan cepat.

6. 📝 /buatjs
➡️ Butuh bantuan? Jelaskan apa yang ingin kamu buat, kami bantu!

7. 📹 /yts
➡️ Cari video YouTube terbaru dengan detail lengkap.

8. 🎶 /ytmp3
➡️ Download audio MP3 dari video YouTube favoritmu.

9. 🕌 /infopuasa
➡️ Dapatkan jadwal dan tips seputar puasa dengan mudah.

10. 🧾 /cetakstruk
➡️ Cetak struk transaksi atau data lainnya dengan desain rapi.

11. 🤖 /ai
➡️ Bot Respons Ai Chat-GPT-3 Akan Sering Terjadi Error

12. 🤩 /cekcantik
➡️ Cek Kecantikanmu Disini Ada Kata Mutiara loh

13. 😎 /cekganteng
➡️ Cek Kegantenganmu Disini Khusus Dapet Jelek Mohon Maaf🙏

14. 👹 /cekkhodam
➡️ Cek Khodammu Disini Dapatkan Khodam Mengerikan.

15. 🧰 /buyjasa
➡️ Cek Jasa Yang Tersedia Di KenzDeveloper.

16. 🛍 /shop
➡️ List Shop Yang Tersedia Di KenzDeveloper.

17. 🔎 /searchapk
➡️ Cari Apk Di Uptodown Jika Error Admin Fix.

18. ▶️ /ytmp4
➡️ Download Video YouTube Dengan Link.

19. 🔎 /google
➡️ Cari Informasi Di Google Bot Dengan Mudah.

20. 🛠 /obfuscate
➡️ Buat Kode JavaScript Menjadi ENC.

21. 💰 /donasi
➡️ Donasi Ke KenzDev Biar Semangat Dan Bagi Bagi Gratis.


🕵️‍♂️ 🔍 STALKING MENU 🔍

Pantau akun atau cari informasi lebih dalam:

1. 👤 /stalk
➡️ Cari tahu info dari akun media sosial yang kamu inginkan.

2. 🔎 /stalkig
➡️ Lakukan pencarian mendalam di dunia maya.


📈 💸 SAHAM MENU 💸

Panduan dan informasi untuk dunia saham:

1. 📊 /investasisaham1
➡️ Mulai perjalanan investasimu dengan panduan lengkap.

2. 📈 /investasisaham2
➡️ Lanjutkan dengan tips dan strategi investasi saham lainnya.

3. 💹 /lelangsaham
➡️ Ikuti lelang saham terkini dan dapatkan harga terbaik!


📫 BERITA MENU 📫

Dapatkan Informasi Menegangkan:

1. 📩 /berita
➡️ Dapatkan Berita Dari Info Berita.

2. 📩 /infobmkg
➡️ Dapatkan Berita Dari BMKG.


💾 SUBDO MENU 💾

List Subdo Tersedia Di KenzDev

1. 🌐 /subdo
➡️ Menampilkan Domain Tersedia Di KenzDev

©️ KENZDEV 2025
`)
resultJw = ` Bot By KenzDeveloper`
setTimeout(() => {;
bot.sendMessage(chatId, `\`\`\`\n${resultJw}\n\`\`\``,
{ parse_mode: 'Markdown' })
},300)
})
//==================//
// Perintah untuk membuat shortlink
bot.onText(/\/shortlink (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const longUrl = match[1].trim(); // URL yang dimasukkan pengguna

  // Kirim pesan "Sedang memproses..."
  const loadingMessage = await bot.sendMessage(chatId, "🔗 Sedang memproses tautan Anda...");

  try {
    // Buat shortlink menggunakan Bitly
    const shortlink = await createShortlink(longUrl);

    // Edit pesan untuk menampilkan hasil
    await bot.editMessageText(`✅ Shortlink berhasil dibuat:\n${shortlink}`, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
      
    });
  } catch (error) {
    // Tampilkan pesan error jika gagal
    await bot.editMessageText(`❌ ${error.message}`, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  }
});

bot.onText(/\/shortlink2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const longUrl1 = match[1].trim(); // URL yang dimasukkan pengguna

  // Kirim pesan "Sedang memproses..."
  const loadingMessage = await bot.sendMessage(chatId, "🔗 Sedang memproses tautan Anda...");

  try {
    // Buat shortlink menggunakan Bitly
    const shortlink1 = await createShortlink(longUrl1);

    // Edit pesan untuk menampilkan hasil
    await bot.editMessageText(`✅ Shortlink berhasil dibuat:\n${shortlink1}`, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  } catch (error) {
    // Tampilkan pesan error jika gagal
    await bot.editMessageText(`❌ ${error.message}`, {
      chat_id: chatId,
      message_id: loadingMessage.message_id,
    });
  }
});
//==================//
//play
// Perintah /yts
bot.onText(/\/yts (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]; // Ambil teks setelah perintah /play

  bot.sendMessage(chatId, `🔍 Mencari lagu: "${query}"...`);

  try {
    // Cari video di YouTube
    const videoUrl = await searchYouTube(query);

    if (!videoUrl) {
      bot.sendMessage(chatId, "❌ Lagu tidak ditemukan.");
      return;
    }

    bot.sendMessage(chatId, `🎵 Lagu ditemukan: ${videoUrl}`);

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memutar lagu.");
  }
});
//==================//
// Perintah /ytmp3
bot.onText(/\/ytmp3 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];
  const videoId = extractVideoId(url);

  if (!videoId) {
    bot.sendMessage(chatId, "❌ URL tidak valid. Pastikan Anda memasukkan URL YouTube yang benar.");
    return;
  }

  try {
    // Ambil informasi video
    bot.sendMessage(chatId, "🔍 Mengambil informasi video...");
    const videoInfo = await getYouTubeVideoInfo(videoId);
    const title = videoInfo.items[0]?.snippet?.title || "Audio YouTube";

    // Unduh audio
    bot.sendMessage(chatId, `🎵 Mengunduh audio: ${title}`);
    const filePath = `./${videoId}.mp3`;
    await downloadYouTubeAudio(videoId, filePath);

    // Kirim audio ke pengguna
    bot.sendAudio(chatId, filePath, {
      title,
      performer: "YouTube",
    });

    // Hapus file setelah dikirim
    fs.unlinkSync(filePath);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses permintaan Anda.");
  }
});
//==================//
// Perintah untuk memulai fitur buathtml
bot.onText(/\/buathtml/, (msg) => {
  const chatId = msg.chat.id;
  userState[chatId] = { step: "judul" }; // Menyimpan status pengguna untuk langkah "judul"

  bot.sendMessage(chatId, "📄 Silakan masukkan judul untuk file HTML Anda.");
});

// Menangani pesan setelah perintah /buathtml
bot.on('message', (msg) => {
  const chatId = msg.chat.id;

  // Jika pengguna berada pada langkah "judul"
  if (userState[chatId]?.step === "judul") {
    const title = msg.text;

    // Simpan judul ke dalam status pengguna
    userState[chatId].title = title;
    userState[chatId].step = "konten"; // Pindah ke langkah berikutnya

    bot.sendMessage(chatId, `📄 Judul Anda: *${title}*\nSekarang masukkan konten untuk file HTML.`, {
      parse_mode: "Markdown",
    });
  }
  // Jika pengguna berada pada langkah "konten"
  else if (userState[chatId]?.step === "konten") {
    const content = msg.text;
    const title = userState[chatId].title;

    // Buat file HTML
    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body>
  <h1>${title}</h1>
  <p>${content}</p>
</body>
</html>
    `;

    // Simpan file HTML
    const filePath = `./${chatId}_file.html`;
    fs.writeFileSync(filePath, htmlContent);

    // Kirim file HTML ke pengguna
    bot.sendDocument(chatId, filePath, {}, {
      filename: `${title}.html`,
      contentType: 'text/html',
    }).then(() => {
      // Hapus status pengguna setelah file dikirim
      delete userState[chatId];
      // Hapus file dari server
      fs.unlinkSync(filePath);
    }).catch((err) => {
      console.error(err);
      bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengirim file.");
    });
  }
});
//===============//
// Fitur Stalking untuk mencari informasi pengguna
bot.onText(/\/stalk (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const usernameToStalk = match[1]; // Mengambil username yang dimasukkan oleh pengguna

  try {
    // Menyaring hasil berdasarkan username
    const user = await bot.getChat(usernameToStalk);

    const userInfo = `
📸 *Informasi Pengguna*:
- *Username:* @${user.username || "Tidak ada username"}
- *Nama Depan:* ${user.first_name}
- *Nama Belakang:* ${user.last_name || "Tidak ada"}
- *ID Pengguna:* ${user.id}
- *Tipe Chat:* ${user.type}
    `;

    bot.sendMessage(chatId, userInfo, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(chatId, "❌ Pengguna tidak ditemukan atau tidak dapat diakses.");
  }
});

// Fitur Default untuk mendapatkan info pengguna yang mengirimkan pesan
bot.on('message', (msg) => {
  const chatId = msg.chat.id;

  if (msg.text && msg.text.toLowerCase() === '/stalk') {
    const userInfo = `
📸 *Informasi Pengguna Anda*:
- *Username:* @${msg.from.username || "Tidak ada username"}
- *Nama Depan:* ${msg.from.first_name}
- *Nama Belakang:* ${msg.from.last_name || "Tidak ada"}
- *ID Pengguna:* ${msg.from.id}
- *Tipe Chat:* ${msg.chat.type}
    `;

    bot.sendMessage(chatId, userInfo, { parse_mode: 'Markdown' });
  }
});
//===============//
// Perintah untuk stalking Instagram
bot.onText(/\/stalkig (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1]; // Username Instagram yang dimasukkan oleh pengguna
  
  try {
    // Mengambil data profil Instagram menggunakan Instagram-scraper
    const user = await InstagramScraper.getProfile(username);

    const userInfo = `
🔍 *Informasi Akun Instagram*:
- *Username:* @${user.username}
- *Nama:* ${user.full_name}
- *Bio:* ${user.biography || "Tidak ada bio"}
- *Jumlah Pengikut:* ${user.followers_count}
- *Jumlah Mengikuti:* ${user.following_count}
- *Jumlah Postingan:* ${user.media_count}
- *URL Profil:* [Instagram Profile](https://www.instagram.com/${user.username}/)
    `;

    // Mengirimkan informasi pengguna
    bot.sendMessage(chatId, userInfo, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(chatId, "❌ Tidak dapat menemukan akun Instagram atau akun bersifat privat.");
  }
});
//===============//
// Mengambil query dan memberikan hasil CSS otomatis
bot.onText(/\/buatcss (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]; // Query yang dimasukkan pengguna
  
  let cssResult = '';

  // Mengecek query yang diberikan dan memberikan hasil CSS yang sesuai
  switch (query.toLowerCase()) {
    case 'background':
      cssResult = `
/* CSS untuk background */
background-color: #ffffff; /* Ganti dengan warna yang diinginkan */
background-image: url('path/to/image.jpg'); /* Ganti dengan URL gambar */
background-size: cover;
      `;
      break;

    case 'font':
      cssResult = `
/* CSS untuk font */
font-family: 'Arial', sans-serif; /* Ganti dengan font yang diinginkan */
font-size: 16px; /* Ganti dengan ukuran font */
font-weight: bold;
      `;
      break;

    case 'border':
      cssResult = `
/* CSS untuk border */
border: 2px solid #000000; /* Ganti dengan warna dan ketebalan border */
border-radius: 5px; /* Ganti dengan nilai radius border */
      `;
      break;

    case 'padding':
      cssResult = `
/* CSS untuk padding */
padding: 10px; /* Ganti dengan nilai padding */
padding-top: 5px;
padding-bottom: 5px;
      `;
      break;

    case 'margin':
      cssResult = `
/* CSS untuk margin */
margin: 20px; /* Ganti dengan nilai margin */
margin-top: 10px;
margin-bottom: 10px;
      `;
      break;

    default:
      cssResult = '❌ Query tidak ditemukan. Coba query lain seperti "background", "font", "border", "padding", atau "margin".';
      break;
  }

  // Mengirimkan hasil CSS kepada pengguna
  bot.sendMessage(chatId, `Berikut adalah CSS untuk query "${query}":\n\n\`\`\`css\n${cssResult}\n\`\`\``, {
    parse_mode: 'Markdown'
  });
});
//===============//
// Meminta pengguna untuk memasukkan permintaan JavaScript
bot.onText(/\/buatjs/, (msg) => {
  const chatId = msg.chat.id;
  userState[chatId] = { step: "js" }; // Menyimpan status pengguna untuk langkah "js"

  bot.sendMessage(chatId, "🖋️ Silakan masukkan permintaan untuk membuat JavaScript. Misalnya, 'buatkan script untuk menambahkan event click pada tombol'.");
});

// Menangani input JavaScript dan mengirimkan hasilnya
bot.on('message', (msg) => {
  const chatId = msg.chat.id;

  if (userState[chatId]?.step === "js") {
    const request = msg.text;

    let resultJs = '';

    // Logika untuk menghasilkan JavaScript berdasarkan permintaan
    if (request.toLowerCase().includes('event click')) {
      resultJs = `
document.querySelector('button').addEventListener('click', function() {
  alert('Button clicked!');
});
      `;
    } else if (request.toLowerCase().includes
      ('bot script')) {
      resultJs = `/* SCRIPT BOT */
const TelegramBot = require("node-telegram-bot-api");

// Masukkan token bot Anda
const token = "${token}";
const bot = new TelegramBot(token, { polling: true });

// Fungsi utama bot
bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  
  // Respon default
  if (msg.text === "/start") {
    bot.sendMessage(chatId, "Selamat datang di bot Telegram Anda!");
  }

  // Respon khusus fitur:
  if (msg.text === "/help") {
    bot.sendMessage(chatId, "Ini adalah fitur!");
  }
});

console.log("Bot berhasil dijalankan!");
      `;
    } else if (request.toLowerCase().includes('hitung angka')) {
      resultJs = `
function hitungAngka(a, b) {
  return a + b;
}
console.log(hitungAngka(5, 10)); // Output: 15
      `;
    } else if (request.toLowerCase().includes('ubah warna')) {
      resultJs = `
document.body.style.backgroundColor = 'lightblue'; // Mengubah warna latar belakang
      `;
    } else {
      resultJs = "🚫 Permintaan tidak dikenali. Silakan coba dengan permintaan lain seperti 'event click' , 'hitung angka' , 'bot script'.";
    }

    // Mengirimkan hasil JavaScript kepada pengguna
    bot.sendMessage(chatId, "✅ Berikut adalah script JavaScript yang dihasilkan:\n\n" + "```javascript\n" + resultJs + "\n```", {
      parse_mode: 'Markdown'
    });

    // Reset status pengguna
    delete userState[chatId];
  }
});
//===============//
// Perintah untuk menampilkan waktu mundur menuju Ramadan
bot.onText(/\/infopuasa/, (msg) => {
  const chatId = msg.chat.id;
  const img = "https://telegra.ph/file/c1e45131e3702d2150d2f.jpg"
  
  // Hitung waktu mundur dan kirimkan ke pengguna
  const pesan = hitungWaktuMundur();
  bot.sendPhoto(chatId, img, 
  {
    caption: pesan
  })
});
//===============//
// Perintah /start
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;

  // Kirim pesan awal
  const loadingMessage = await bot.sendMessage(chatId, "⏳ Loading...");

  // Simpan ID pesan untuk diperbarui
  const messageId = loadingMessage.message_id;

  // Array teks animasi loading
  const loadingSteps = [
    "⌛ Loading.",
    "⏳ Loading..",
    "⌛ Loading...",
    "⏳ Loading....",
  ];

  let step = 0;

  // Fungsi untuk memperbarui teks loading
  const interval = setInterval(() => {
    if (step < loadingSteps.length) {
      bot.editMessageText(loadingSteps[step], {
        chat_id: chatId,
        message_id: messageId,
      });
      step++;
    } else {
      clearInterval(interval);

      // Jika loading selesai, tampilkan pesan selesai
      bot.editMessageText(
        "✅ LOADING SUDAH SELESAI SILAHKAN KLIK INI\n/menu",
        {
          chat_id: chatId,
          message_id: messageId,
        }
      );
    }
  }, 1000); // Update setiap 1 detik
});
//===============//
// Perintah untuk membeli subdomain
bot.onText(/\/belisubdo (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const [subdomain, ip] = match[1].split(" ");

  if (!subdomain || !ip) {
    bot.sendMessage(
      chatId,
      "❌ Format salah! Gunakan format:\n/belisubdo <subdomain> <ip>"
    );
    return;
  }

  bot.sendMessage(chatId, "⏳ Membuat subdomain...");

  // Buat subdomain
  const hasil = await buatSubdomain(subdomain, ip);

  // Kirim hasil
  bot.sendMessage(chatId, hasil);
});
//===============//
// Perintah memulai investasi
bot.onText(/\/investasisaham1/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(
    chatId,
    `📈 Selamat datang di fitur Investasi Saham! 💰\n\nMasukkan jumlah investasi awal Anda (contoh: 100000):`
  );

  bot.once("message", (msg) => {
    const investasiAwal = parseInt(msg.text);
    if (isNaN(investasiAwal) || investasiAwal <= 0) {
      bot.sendMessage(chatId, "❌ Harap masukkan jumlah investasi yang valid.");
      return;
    }

    // Simpan data investasi pengguna
    investasiPengguna[chatId] = {
      investasiAwal,
      persenKeuntungan: 0, // Awalnya 0%
    };

    bot.sendMessage(
      chatId,
      `✅ Investasi sebesar Rp${investasiAwal.toLocaleString()} berhasil dicatat! 🎉\n\nKetik /cek untuk melihat status investasi Anda.`
    );
  });
});

// Perintah untuk mengecek status investasi
bot.onText(/\/ceksaham/, (msg) => {
  const chatId = msg.chat.id;
  const dataInvestasi = investasiPengguna[chatId];

  if (!dataInvestasi) {
    bot.sendMessage(
      chatId,
      "❌ Anda belum memulai investasi. Ketik /investasisaham untuk memulai. 📈"
    );
    return;
  }

  const { investasiAwal, persenKeuntungan } = dataInvestasi;
  const totalInvestasi = hitungKeuntungan(investasiAwal, persenKeuntungan);

  bot.sendMessage(
    chatId,
    `💹 Status Investasi Anda:\n\n🪙 Investasi Awal: Rp${investasiAwal.toLocaleString()}\n📈 Persen Keuntungan: ${persenKeuntungan}%\n💰 Total Nilai: Rp${totalInvestasi.toLocaleString()}\n\nTingkatkan keuntungan Anda dengan /naikkankeuntungan! 🚀`
  );
});

// Perintah untuk meningkatkan keuntungan investasi
bot.onText(/\/naikkankeuntungan/, (msg) => {
  const chatId = msg.chat.id;
  const dataInvestasi = investasiPengguna[chatId];

  if (!dataInvestasi) {
    bot.sendMessage(
      chatId,
      "❌ Anda belum memulai investasi. Ketik /mulaiinvestasi untuk memulai. 📈"
    );
    return;
  }

  const randomKeuntungan = Math.floor(Math.random() * 5) + 1; // Keuntungan acak 1% - 5%
  dataInvestasi.persenKeuntungan += randomKeuntungan;

  bot.sendMessage(
    chatId,
    `🎉 Selamat! Keuntungan investasi Anda naik sebesar ${randomKeuntungan}% 📊\nKetik /cek untuk melihat status terbaru Anda!`
  );
});
//===============//
// Perintah untuk memulai lelang saham
bot.onText(/\/lelangsaham/, (msg) => {
  const chatId = msg.chat.id;

  // Jika sudah ada lelang aktif, beri peringatan
  if (lelang.aktif) {
    bot.sendMessage(chatId, "❌ Lelang saham sedang berlangsung! Gunakan /akhiri untuk menyelesaikannya.");
    return;
  }

  bot.sendMessage(chatId, "📢 Masukkan nama saham yang akan dilelang:");
  bot.once("message", (msg) => {
    const saham = msg.text;

    bot.sendMessage(chatId, "💰 Masukkan harga awal saham:");
    bot.once("message", (msg) => {
      const hargaAwal = parseInt(msg.text);
      if (isNaN(hargaAwal) || hargaAwal <= 0) {
        bot.sendMessage(chatId, "❌ Harap masukkan harga awal yang valid.");
        return;
      }

      // Mulai lelang
      lelang = {
        aktif: true,
        saham,
        hargaAwal,
        penawaran: [],
      };

      bot.sendMessage(
        chatId,
        `✅ Lelang saham "${saham}" telah dimulai!\n💵 Harga awal: ${formatRupiah(hargaAwal)}\n\nGunakan /tawar <jumlah> untuk memasang tawaran. Lihat Lelang /statuslelang`
      );
    });
  });
});

// Perintah untuk memasang tawaran
bot.onText(/\/tawar (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const jumlahTawaran = parseInt(match[1]);

  if (!lelang.aktif) {
    bot.sendMessage(chatId, "❌ Tidak ada lelang saham yang aktif saat ini.");
    return;
  }

  if (isNaN(jumlahTawaran) || jumlahTawaran <= lelang.hargaAwal) {
    bot.sendMessage(
      chatId,
      `❌ Tawaran Anda harus lebih besar dari harga awal (${formatRupiah(lelang.hargaAwal)}) atau penawaran sebelumnya.`
    );
    return;
  }

  // Simpan tawaran
  lelang.penawaran.push({
    userId: msg.from.id,
    nama: msg.from.first_name || "Pengguna",
    jumlah: jumlahTawaran,
  });

  // Update harga awal
  lelang.hargaAwal = jumlahTawaran;

  bot.sendMessage(
    chatId,
    `🎉 ${msg.from.first_name || "Pengguna"} telah menawar ${formatRupiah(jumlahTawaran)}!\nGunakan /tawar <jumlah> untuk memasang tawaran lebih tinggi.`
  );
});

// Perintah untuk melihat status lelang
bot.onText(/\/statuslelang/, (msg) => {
  const chatId = msg.chat.id;

  if (!lelang.aktif) {
    bot.sendMessage(chatId, "❌ Tidak ada lelang saham yang aktif saat ini.");
    return;
  }

  const { saham, hargaAwal, penawaran } = lelang;
  const penawarTertinggi = penawaran.length
    ? penawaran[penawaran.length - 1]
    : { nama: "Belum ada penawar", jumlah: hargaAwal };

  bot.sendMessage(
    chatId,
    `📈 Status Lelang:\n\n🪙 Saham: ${saham}\n💵 Harga Awal: ${formatRupiah(hargaAwal)}\n👑 Penawar Tertinggi: ${penawarTertinggi.nama} (${formatRupiah(penawarTertinggi.jumlah)})\n\nGunakan /tawar <jumlah> untuk menawar lebih tinggi.`
  );
});

// Perintah untuk mengakhiri lelang
bot.onText(/\/akhiri/, (msg) => {
  const chatId = msg.chat.id;

  if (!lelang.aktif) {
    bot.sendMessage(chatId, "❌ Tidak ada lelang saham yang aktif saat ini.");
    return;
  }

  const { saham, penawaran } = lelang;
  const penawarTertinggi = penawaran.length
    ? penawaran[penawaran.length - 1]
    : null;

  if (penawarTertinggi) {
    bot.sendMessage(
      chatId,
      `🎉 Lelang saham "${saham}" telah selesai!\n\n👑 Pemenang: ${penawarTertinggi.nama}\n💵 Harga Akhir: ${formatRupiah(penawarTertinggi.jumlah)}`
    );
  } else {
    bot.sendMessage(chatId, `❌ Lelang saham "${saham}" tidak memiliki penawar.`);
  }

  // Reset lelang
  lelang = {
    aktif: false,
    saham: null,
    hargaAwal: 0,
    penawaran: [],
  };
});
//===============//
// Perintah untuk melihat investasi saham
bot.onText(/\/investasisaham2/, async (msg) => {
  const chatId = msg.chat.id;

  // Kirim pesan yang menampilkan harga saham dan grafik naik/turun
  bot.sendMessage(chatId, "🔄 Mengambil data saham terbaru...");

  // Simulasi harga saham naik-turun
  const { hargaSaham, naikTurun, emoji } = generateSaham();

  // Menampilkan harga saham dengan emoji naik/turun
  const pesan = `💹 Harga Saham Terbaru : ${hargaSaham} IDR\n` +
                `📊 Status : ${emoji} Saham ${naikTurun}.\n\n` +
                `✅ Update harga otomatis setiap 10 detik.`;

  const sentMessage = await bot.sendMessage(chatId, pesan);

  // Simulasi pembaruan harga saham setiap 10 detik
  setInterval(() => {
    const { hargaSaham, naikTurun, emoji } = generateSaham();
    const updateMessage = `💹 Harga Saham Terbaru: ${hargaSaham} IDR\n\n` +
                          `📊 Status: ${emoji} Saham ${naikTurun}.\n\n` + 
                          `Powered By @KenzDeveloper`;

    bot.editMessageText(updateMessage, {
      chat_id: chatId,
      message_id: sentMessage.message_id
    });
  }, 10000); // Perbarui setiap 10 detik
});
//===============//
// Perintah untuk memulai input struktur pembayaran
bot.onText(/\/cetakstruk/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "🔸 Masukkan Nama Barang yang ingin Anda beli:");
  
  // Tunggu input nama barang
  bot.once('message', (msg) => {
    const namaBarang = msg.text;

    bot.sendMessage(chatId, `🔸 Masukkan Harga Barang untuk ${namaBarang}:`);

    // Tunggu input harga barang
    bot.once('message', (msg) => {
      const hargaBarang = parseFloat(msg.text);
      
      if (isNaN(hargaBarang)) {
        bot.sendMessage(chatId, "❌ Harga tidak valid. Silakan masukkan harga dalam angka.");
        return;
      }

      bot.sendMessage(chatId, `🔸 Masukkan Jumlah Beli ${namaBarang}:`);

      // Tunggu input jumlah beli
      bot.once('message', (msg) => {
        const jumlahBeli = parseInt(msg.text);

        if (isNaN(jumlahBeli) || jumlahBeli <= 0) {
          bot.sendMessage(chatId, "❌ Jumlah beli tidak valid. Masukkan jumlah yang lebih besar dari 0.");
          return;
        }

        // Membuat struktur pembayaran
        const strukturPembayaran = buatStrukturPembayaran(namaBarang, hargaBarang, jumlahBeli);

        // Mengirim struktur pembayaran ke pengguna
        bot.sendMessage(chatId, strukturPembayaran);
      });
    });
  });
});
//===============//
// Perintah untuk cek khodam
bot.onText(/\/cekkhodam/, (msg) => {
  const chatId = msg.chat.id;

  // Mendapatkan khodam acak
  const khodamResult = getKhodam();

  // Kirimkan hasil cek khodam ke pengguna
  bot.sendMessage(chatId, `🔮 Cek Khodammu: ${khodamResult.name} ${khodamResult.emoji}\n\n${khodamResult.description}`);
});

//===============//
// Command untuk memulai proses pengisian data pembayaran
bot.onText(/\/buatpayment/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "💳 Masukkan Atas Nama DANA :");

  // Tunggu input nama DANA
  bot.once("message", (msg) => {
    const namaDana = msg.text;

    bot.sendMessage(chatId, "📞 Masukkan Nomor DANA :");

    // Tunggu input nomor DANA
    bot.once("message", (msg) => {
      const nomorDana = msg.text;

      bot.sendMessage(chatId, "💳 Masukkan Atas Nama GO-PAY :");

      // Tunggu input nama GO-PAY
      bot.once("message", (msg) => {
        const namaGoPay = msg.text;

        bot.sendMessage(chatId, "📞 Masukkan Nomor GO-PAY :");

        // Tunggu input nomor GO-PAY
        bot.once("message", (msg) => {
          const nomorGoPay = msg.text;

          bot.sendMessage(chatId, "🔗 Masukkan URL QRIS :");

          // Tunggu input URL QRIS
          bot.once("message", (msg) => {
            const qrisURL = msg.text;

            // Generate teks payment
            const paymentText = generatePaymentText(namaDana, nomorDana, namaGoPay, nomorGoPay, qrisURL);

            // Kirim teks payment ke pengguna
            bot.sendMessage(chatId, paymentText, { parse_mode: "Markdown" });
          });
        });
      });
    });
  });
});
//===============//
// Perintah untuk memeriksa status bot
bot.onText(/\/runtime/, (msg) => {
  const chatId = msg.chat.id;

  // Cek apakah bot berjalan
  bot.sendMessage(chatId, "✅ **Bot sedang aktif!**\n\n🌐 Status: Online\n🤖 Bot: Berfungsi dengan baik\n⌛ Waktu aktif: " + "${uptime}");
});
//===============//
// Command untuk mendapatkan berita terbaru
bot.onText(/\/berita/, async (msg) => {
  const chatId = msg.chat.id;

  // Mengambil berita terbaru
  const news = await getLatestNews();

  // Mengirimkan berita kepada pengguna
  bot.sendMessage(chatId, news, { parse_mode: 'Markdown' });
});
//===============//
// Perintah untuk cek ganteng
bot.onText(/\/cekganteng/, (msg) => {
  const chatId = msg.chat.id;

  // Menentukan tingkat kegantengan pengguna secara acak
  const gantengResult = getGantengLevel();

  // Kirimkan pesan ke pengguna
  bot.sendMessage(chatId, `🗿 Cek Gantengmu: ${gantengResult.level} ${gantengResult.emoji}`);
});
//===============//
// Perintah untuk membuat QR Code
bot.onText(/\/bikinqrcode/, (msg) => {
  const chatId = msg.chat.id;

  // Meminta input pengguna untuk membuat QR code
  bot.sendMessage(chatId, 'Silakan masukkan nama atau link untuk membuat QR Code:');
  
  bot.on('message', (response) => {
    const userInput = response.text;

    // Membuat QR code dari input pengguna dan mengirimkan QR Code sebagai gambar
    QRCode.toDataURL(userInput, function (err, url) {
      if (err) {
        console.error('Error generating QR Code:', err);
        bot.sendMessage(chatId, 'Maaf, terjadi kesalahan dalam membuat QR Code.');
      } else {
        // Mengirimkan QR Code kepada pengguna
        bot.sendMessage(chatId, 'Ini adalah QR Code Anda:');
        bot.sendPhoto(chatId, url, { caption: 'QR Code telah dibuat!' });
      }
    });
  });
});
//===============//

//===============/
// Menggunakan perintah /cekcantik
bot.onText(/\/cekcantik/, (msg) => {
  const chatId = msg.chat.id;
  const beautyMessage = getBeautyRating(); // Mendapatkan hasil acak cek cantik
  bot.sendMessage(chatId, beautyMessage);
});
//===============//
// Menggunakan perintah /infobmkg
bot.onText(/\/infobmkg/, (msg) => {
  const chatId = msg.chat.id;

  // Mengambil informasi gempa dari RSS Feed dan mengirimkannya ke pengguna
  getEarthquakeFromRSS((earthquakeInfo) => {
    bot.sendMessage(chatId, earthquakeInfo, { parse_mode: 'Markdown' });
  });
});
//===============//
// Ketika pengguna mengetik /jasa
bot.onText(/\/buyjasa/, (msg) => {
    const chatId = msg.chat.id;

    // Tampilkan pilihan jasa dengan emoji
    bot.sendMessage(
        chatId,
        "Pilih jasa yang ingin Anda gunakan:\n\n" +
        "1. 🖥️ Jasa Install Panel\n" +
        "2. 🔓 Jasa Unband Nomor\n" +
        "3. 🔒 Jasa Band Nomor\n" +
        "4. 💼 Jasa Jasteb\n\n" +
        "Ketik /installPanel untuk memilih Jasa Install Panel, /unbandNomor untuk memilih Jasa Unband Nomor, /bandNomor untuk memilih Jasa Band Nomor, /jasteb untuk memilih Jasa Jasteb."
    );
});

// Ketika pengguna memilih jasa
bot.onText(/\/(installPanel|unbandNomor|bandNomor|jasteb)/, (msg, match) => {
    const chatId = msg.chat.id;
    const jasa = match[1];
    const selectedJasa = jasaData[jasa];

    // Tampilkan deskripsi jasa dengan emoji
    bot.sendMessage(
        chatId,
        `Anda memilih ${selectedJasa.nama}.\n\n` +
        `Deskripsi: ${selectedJasa.deskripsi}\n` +
        `Harga: ${selectedJasa.harga}\n\n` +
        "💰 Silakan kirimkan bukti transfer Anda setelah pembayaran."
    );
});

// Ketika pengguna mengirim bukti transfer
bot.onText(/\/transfer (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const jumlahTransfer = parseInt(match[1]);

    // Menyimpan bukti transfer dengan waktu
    addTransferData(chatId, jumlahTransfer);

    // Kirimkan konfirmasi ke admin
    bot.sendMessage(
        ADMIN_ID,
        `💸 Pengguna @${msg.from.username} telah mengirim bukti transfer:\n` +
        `Jumlah transfer: Rp${jumlahTransfer.toLocaleString()}\n` +
        `ID Pengguna: ${chatId}\n\n` +
        "Silakan cek dan konfirmasi apakah transfer sudah sesuai."
    );

    // Memberitahukan pengguna
    bot.sendMessage(
        chatId,
        "🙏 Terima kasih telah mentransfer. Admin akan segera memverifikasi pembayaran Anda."
    );

    // Set timer 5 menit untuk pembatalan otomatis jika belum dikonfirmasi
    setTimeout(() => {
        // Jika status pembayaran masih Pending setelah 5 menit, otomatis tolak
        if (transferData[chatId] && transferData[chatId].status === 'Pending') {
            transferData[chatId].status = 'Ditolak';

            bot.sendMessage(
                chatId,
                "⏳ Waktu konfirmasi pembayaran Anda telah habis. Pembayaran Anda ditolak."
            );
            bot.sendMessage(
                ADMIN_ID,
                `❌ Pembayaran pengguna @${msg.from.username} ditolak secara otomatis karena belum terkonfirmasi dalam waktu 5 menit.`
            );
        }
    }, 5 * 60 * 1000); // 5 menit dalam milidetik
});

// Ketika admin mengonfirmasi pembayaran
bot.onText(/\/konfirmasi (\d+) (\w+)/, (msg, match) => {
    const adminId = msg.chat.id;
    const userId = match[1];
    const status = match[2];

    if (adminId !== ADMIN_ID) {
        bot.sendMessage(adminId, "🚫 Anda bukan admin.");
        return;
    }

    if (!transferData[userId]) {
        bot.sendMessage(adminId, "⚠️ Data pengguna tidak ditemukan.");
        return;
    }

    // Update status pembayaran
    transferData[userId].status = status;

    if (status === 'Diterima') {
        bot.sendMessage(userId, `✅ Pembayaran Anda telah diterima! Jasa ${jasaData[userId].nama} akan segera diproses.`);
        bot.sendMessage(adminId, `✅ Pembayaran pengguna @${userId} diterima.`);
    } else {
        bot.sendMessage(userId, "❌ Pembayaran Anda tidak diterima. Silakan coba lagi.");
        bot.sendMessage(adminId, `❌ Pembayaran pengguna @${userId} ditolak.`);
    }
});
//===============//
// Fitur perintah /shop untuk membuka menu produk
bot.onText(/\/shop/, (msg) => {
  const chatId = msg.chat.id;
  showShopMenu(chatId);
});

// Fitur untuk memilih produk dari daftar
bot.onText(/^[1-7]$/, (msg, match) => {
  const chatId = msg.chat.id;
  const productId = parseInt(match[0]);
  processOrder(chatId, productId);
});

// Fitur untuk konfirmasi pembayaran
bot.onText(/\/konfirmasi/, (msg) => {
  const chatId = msg.chat.id;
  confirmPayment(chatId);
  t = `JIKA TIDAK TERKIRIM SILAHKAN CHAT OWNER`
  setTimeout(() => {;
bot.sendMessage(chatId, `\`\`\`\n${t}\n\`\`\``,
{ parse_mode: 'Markdown' })
},300)
});
//===============//
// Fungsi untuk mengirim informasi kecepatan server
bot.onText(/\/kecepatanserver/, async (msg) => {
  const chatId = msg.chat.id;

  try {
    // Mengambil ping server
    const ping = await getServerPing();

    // Mengambil statistik server (CPU dan Memori)
    const serverStats = await getServerStats();

    // Mengirim hasil
    bot.sendMessage(chatId, `🌐 Kecepatan Server 🌐
⚡ Ping : ${ping} ms
      ${serverStats}
    `);
  } catch (error) {
    bot.sendMessage(chatId, '❌ Terjadi kesalahan dalam mendapatkan informasi kecepatan server.');
  }
});
//===============//
// Perintah untuk mencari lirik
bot.onText(/\/carilirik (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const lagu = match[1];

  bot.sendMessage(chatId, 'Mencari lirik... Harap tunggu sebentar...');

  // Mengambil lirik lagu
  try {
    const lirik = await cariLirik(lagu);
    bot.sendMessage(chatId, `Lirik lagu ${lagu}:\n\n${lirik}`);
  } catch (error) {
    bot.sendMessage(chatId, 'Terjadi kesalahan dalam mencari lirik.');
  }
});
//====================//
bot.onText(/\/kenzdev/, async (msg) => {
  const chatId = msg.chat.id
  bot.sendMessage(chatId, `BOT SUDAH ON PAK CIK🐥`)
});
//==============//
// Fitur Search APK
bot.onText(/\/searchapk (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]; // Nama aplikasi yang dicari

  if (!query) {
    return bot.sendMessage(
      chatId,
      "❗ Harap masukkan nama aplikasi yang ingin dicari.\n" +
        "Contoh: /searchapk WhatsApp"
    );
  }

  bot.sendMessage(chatId, `🔍 Mencari aplikasi "${query}" di Uptodown...`);

  try {
    // URL pencarian di Uptodown
    const searchUrl = `https://en.uptodown.com/search?q=${encodeURIComponent(
      query
    )}`;
    const { data } = await axios.get(searchUrl);
    const $ = cheerio.load(data);

    // Mengambil hasil pencarian pertama
    const appList = [];
    $(".search-item").each((i, el) => {
      if (i >= 5) return false; // Batasi hingga 5 hasil pencarian
      const title = $(el).find(".item-title").text().trim();
      const link = $(el).find(".item-title a").attr("href");
      const desc = $(el).find(".item-excerpt").text().trim();
      if (title && link) {
        appList.push({ title, link, desc });
      }
    });

    if (appList.length === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ditemukan aplikasi dengan nama tersebut."
      );
    }

    // Kirim hasil pencarian
    let message = "🔎 Hasil pencarian aplikasi:\n\n";
    appList.forEach((app, index) => {
      message += `*${index + 1}. ${app.title}*\n` +
        `📄 Deskripsi: ${app.desc}\n` +
        `🔗 [Lihat Aplikasi](https://en.uptodown.com${app.link})\n\n`;
    });

    bot.sendMessage(chatId, message, { parse_mode: "Markdown" });

    // Memberikan opsi unduh APK
    bot.sendMessage(
      chatId,
      "🔽 Untuk mengunduh aplikasi, gunakan perintah berikut:\n" +
        "/downloadapk <nomor_hasil>\n" +
        "Contoh: /downloadapk 1"
    );

    // Simpan data pencarian ke memori (di variabel global)
    global.searchResults = appList;
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat mencari aplikasi. Silakan coba lagi."
    );
  }
});

// Fitur Download APK
bot.onText(/\/downloadapk (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const index = parseInt(match[1]) - 1;

  if (!global.searchResults || !global.searchResults[index]) {
    return bot.sendMessage(
      chatId,
      "❗ Tidak ada hasil pencarian. Gunakan /searchapk terlebih dahulu."
    );
  }

  const selectedApp = global.searchResults[index];

  try {
    bot.sendMessage(chatId, `⏳ Sedang mengambil link unduhan untuk "${selectedApp.title}"...`);

    // Akses halaman aplikasi untuk mendapatkan link unduhan
    const { data } = await axios.get(`https://en.uptodown.com${selectedApp.link}`);
    const $ = cheerio.load(data);
    const downloadLink = $(".download-button").attr("href");

    if (!downloadLink) {
      return bot.sendMessage(
        chatId,
        "❌ Gagal mendapatkan link unduhan. Coba aplikasi lain."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Link unduhan berhasil ditemukan!\n\n` +
        `📦 *${selectedApp.title}*\n` +
        `🔗 [Unduh APK](${downloadLink})\n\n` +
        `⚠️ *Catatan*: Link hanya berlaku dalam beberapa waktu.`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat mengambil link unduhan. Silakan coba lagi."
    );
  }
});
//==================//
/* 
CODE BY KENZDEVELOPER 🐉
YTMP4 BOT TELEGRAM
*/

bot.onText(/\/ytmp4 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]; // URL YouTube yang dimasukkan pengguna

  if (!url) {
    return bot.sendMessage(
      chatId,
      "❗ Masukkan link YouTube yang valid.\nContoh: /ytmp4 https://youtube.com/watch?v=xxxx"
    );
  }

  bot.sendMessage(chatId, `⏳ Sedang memproses link...\n🔗 URL: ${url}`);

  try {
    const { data } = await axios.get(
      `https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(url)}`
    );

    if (data.status === true) {
      
      const downloadUrl = data.result.url;

      // Kirim hasil ke pengguna
      bot.sendPhoto(chatId, thumbnail, {
        caption: `✅ *Berhasil Mendapatkan Video!*\n\n📌 *Judul:* ${title}\n🔗 *URL Download:* [Klik disini](${downloadUrl})\n\n⚠️ *Catatan:* Klik link untuk mengunduh video.`,
        parse_mode: "Markdown",
      });
    } else {
      bot.sendMessage(chatId, "❌ Gagal mendapatkan data video. Link mungkin tidak valid.");
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat memproses permintaan. Coba lagi nanti."
    );
  }
});
//=============//
/*
CODE BY KENZDEVELOPER 🐉
FITUR GOOGLE SEARCH UNTUK BOT TELEGRAM
*/

bot.onText(/\/google (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]; // Query pencarian dari user

  if (!query) {
    return bot.sendMessage(
      chatId,
      "❗ Harap masukkan kata kunci untuk melakukan pencarian.\n" +
        "Contoh: /google cara bikin bot Telegram"
    );
  }

  bot.sendMessage(chatId, `🔍 Sedang mencari "${query}" di Google...`);

  try {
    // Panggil API untuk pencarian Google
    const { data } = await axios.get(
      `https://api.vreden.web.id/api/google?query=${encodeURIComponent(query)}`
    );

    // Proses hasil dari API
    if (!data || !data.result || data.result.length === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada hasil pencarian yang ditemukan.");
    }

    // Format hasil pencarian
    let message = "🔎 *Hasil Pencarian Google:*\n\n";
    data.result.forEach((item, index) => {
      if (index >= 5) return; // Batas 5 hasil pencarian
      message += `*${index + 1}. ${item.title}*\n` +
        `📄 Deskripsi: ${item.snippet}\n` +
        `🔗 [Lihat Hasil](${item.link})\n\n`;
    });

    bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat mencari di Google. Silakan coba lagi."
    );
  }
});
//===============//
//
//==============//
// List Subdo
bot.onText(/\/subdo/,async (msg) => {
    const chatId = msg.chat.id
    const Id = msg.from.id
    const audio1 = "./lagu.mp3"
  let teks = `LIST SUBDO KENZDEV

[ LAYANAN CDN : CLOUDFLARE ]
TOTAL DOMAIN : 5
TOTAL AKTIF DOMAIN : 5

[ ! DISARANKAN UNTUK PTERODACTYL ]

1. alzzoffc-gagal.my.id
2. kenzdeveloper-gacor.biz.id
3. host-server-pterodactyl.my.id
4. kenzhosting.biz.id
5. xyzcloud.my.id
`
bot.sendMessage(Id, teks, {
  reply_markup: {
  inline_keyboard:[
  [
    { text: "🔐SCRIPT", url: "t.me/KenzDeveloper"},
    { text: "👤OWNER", url: "t.me/KenzDeveloper"}
  ],
  [
    { text: "🌐WEBSITE", url: "https://www.kenzbio.alzzoffc-gagal.my.id"}
  ]
  
  ]}
  })
  setTimeout(() => {
  bot.sendMessage(chatId, `LOADING KIRIM LAGU TUNGGU AJA`)
  }, 3000);
  bot.sendAudio(chatId, audio1, 
    {
      caption: `NRESNANI SASYA`
    }
    )
})

